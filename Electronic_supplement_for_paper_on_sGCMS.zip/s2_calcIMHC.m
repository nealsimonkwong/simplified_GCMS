%% Calculate Intensity Measure Hazard Curves (IMHCs) for the site
%{
Inputs:       
    - PSHA data from OpenSHA
    - Domain for computing IMHCs
    
Outputs:
    - IMHC for each T
    - IMHC for each T based on sigma_Arb

Author: Neal Simon Kwong
%}
clear variables; close all; clc;

%% Inputs 
% Load data from OpenSHA
load('.\OpenSHAdata.mat');

% Domain for IMHCs
IMtestPts = logspace(-4,1,51)';

% Specify exposure time for converting rates to probabilities using Poisson
% assumption
exposureTime = 50;

% Specify output dir and filename
outputDir = '.\';
outputFilename = 'PSHAout_IMHC.mat';

%% Compute IMHCs (based on sigma_geo)
% Initialize
IMHC = zeros(length(IMtestPts),nPer); 
probExcInXXyrs = zeros(size(IMHC)); % For plotting against results from OpenSHA GUI
for ii=1:nPer
    for jj = 1:length(IMtestPts)
        % Given vib per and test pt, get standardized variate for each rup
        zz = (log(IMtestPts(jj))-MUs(:,ii)) ./ SIGMAs(:,ii);
        % Get prob of exc given each rup
        probExc = 1 - normcdf( zz );
        % Get total rate of exceedance considering all ruptures
        IMHC(jj,ii) = rupRates' * probExc;
    end    
    probExcInXXyrs(:,ii) = 1 - exp( -IMHC(:,ii)*exposureTime ); % Convert using Poisson process
end

%% Save data
save(fullfile(outputDir,outputFilename),...
    'T','IMtestPts','IMHC');



%% Compute IMHCs (based on sigma_arb)
% Initialize
IMHC_Arb = zeros(length(IMtestPts),nPer); 
probExcInXXyrs_Arb = zeros(size(IMHC_Arb));
for ii=1:nPer
    for jj = 1:length(IMtestPts)
        % Given vib per and test pt, get standardized variate for each rup
        zz = (log(IMtestPts(jj))-MUs(:,ii)) ./ SIGMAs_Arb(:,ii);
        % Get prob of exc given each rup
        probExc = 1 - normcdf( zz );
        % Get total rate of exceedance considering all ruptures
        IMHC_Arb(jj,ii) = rupRates' * probExc;
    end        
    probExcInXXyrs_Arb(:,ii) = 1 - exp( -IMHC_Arb(:,ii)*exposureTime ); % Convert using Poisson process
end

%% Append data
save(fullfile(outputDir,outputFilename),...
    'IMHC_Arb','-append');



%% Plot hazard curve for SA at a given vibration period
% Specify vibration period
Tdisplay = 1;
idT = find( T == Tdisplay );

% Create figure
figure;
semilogy(IMtestPts,probExcInXXyrs(:,idT),'k-');
% Format axes
grid on;
ylim([1e-5 1e0]);
% Format labels
xlabel(['SA(' num2str(T(idT),3) 's) [g]']);
ylabel(['Probability of exceedance in ' int2str(exposureTime) ' years']);
