%% Function for implementing Campbell and Bozorgnia 2008 GMPE for only the periods specified in Campbell and Bozorgnia 2008
% By Neal (Simon) Kwong (nealsimonkwong@berkeley.edu)
% Last modified: 1/21/2014
function [Ageomean, sT, sArb]= CB2008_fixedT(M,Rrup,Rjb,FRV,FNM,ZTOR,dip,VS30,Z2pt5,T)
%{
- 1/21/14: Added coefficients for CAV from CB2010
%}

%% ------------------------INPUT VARIABLES --------------------------------
% M     = Moment magnitude
% Rrup  = Closest Euclidean distance between site and rupture plane (km)
% Rjb   = Closest distance to the surface projection of rupture plane (km)
% FRV   = Indicator variable for reverse or reverse-oblique faulting
% FNM   = Indicator variable for normal or normal-oblique faulting
% ZTOR  = Depth to the top of the rupture plane (km)
% dip   = Dip of the rupture plane (degrees)
% VS30  = Time-averaged shear-wave velocity in the top 30m of site profile (m/s)
% Z2pt5 = Basin or sediment depth (km)
% T     = Period of linear SDOF oscillator or ground motion (sec); T must
%         correspond to one of the 24 rows in the coefficients matrix.

%% Coefficients of CB08
% The columns are: T c0	c1	c2	c3	c4	c5	c6	c7	c8	c9	c10	c11	c12	k1	k2	k3	c	n	slnY	tlnY	slnAF	sC	rho																																					
coefficients = ...
[0.010	-1.715	0.500	-0.530	-0.262	-2.118	0.170	5.60	0.280	-0.120	0.490	1.058	0.040	0.610	865	-1.186	1.839	1.88	1.18	0.478	0.219	0.300	0.166	1.000
0.020	-1.680	0.500	-0.530	-0.262	-2.123	0.170	5.60	0.280	-0.120	0.490	1.102	0.040	0.610	865	-1.219	1.840	1.88	1.18	0.480	0.219	0.300	0.166	0.999
0.030	-1.552	0.500	-0.530	-0.262	-2.145	0.170	5.60	0.280	-0.120	0.490	1.174	0.040	0.610	908	-1.273	1.841	1.88	1.18	0.489	0.235	0.300	0.165	0.989
0.050	-1.209	0.500	-0.530	-0.267	-2.199	0.170	5.74	0.280	-0.120	0.490	1.272	0.040	0.610	1054	-1.346	1.843	1.88	1.18	0.510	0.258	0.300	0.162	0.963
0.075	-0.657	0.500	-0.530	-0.302	-2.277	0.170	7.09	0.280	-0.120	0.490	1.438	0.040	0.610	1086	-1.471	1.845	1.88	1.18	0.520	0.292	0.300	0.158	0.922
0.10	-0.314	0.500	-0.530	-0.324	-2.318	0.170	8.05	0.280	-0.099	0.490	1.604	0.040	0.610	1032	-1.624	1.847	1.88	1.18	0.531	0.286	0.300	0.170	0.898
0.15	-0.133	0.500	-0.530	-0.339	-2.309	0.170	8.79	0.280	-0.048	0.490	1.928	0.040	0.610	878	-1.931	1.852	1.88	1.18	0.532	0.280	0.300	0.180	0.890
0.20	-0.486	0.500	-0.446	-0.398	-2.220	0.170	7.60	0.280	-0.012	0.490	2.194	0.040	0.610	748	-2.188	1.856	1.88	1.18	0.534	0.249	0.300	0.186	0.871
0.25	-0.890	0.500	-0.362	-0.458	-2.146	0.170	6.58	0.280	0.000	0.490	2.351	0.040	0.700	654	-2.381	1.861	1.88	1.18	0.534	0.240	0.300	0.191	0.852
0.30	-1.171	0.500	-0.294	-0.511	-2.095	0.170	6.04	0.280	0.000	0.490	2.460	0.040	0.750	587	-2.518	1.865	1.88	1.18	0.544	0.215	0.300	0.198	0.831
0.40	-1.466	0.500	-0.186	-0.592	-2.066	0.170	5.30	0.280	0.000	0.490	2.587	0.040	0.850	503	-2.657	1.874	1.88	1.18	0.541	0.217	0.300	0.206	0.785
0.50	-2.569	0.656	-0.304	-0.536	-2.041	0.170	4.73	0.280	0.000	0.490	2.544	0.040	0.883	457	-2.669	1.883	1.88	1.18	0.550	0.214	0.300	0.208	0.735
0.75	-4.844	0.972	-0.578	-0.406	-2.000	0.170	4.00	0.280	0.000	0.490	2.133	0.077	1.000	410	-2.401	1.906	1.88	1.18	0.568	0.227	0.300	0.221	0.628
1.0	-6.406	1.196	-0.772	-0.314	-2.000	0.170	4.00	0.255	0.000	0.490	1.571	0.150	1.000	400	-1.955	1.929	1.88	1.18	0.568	0.255	0.300	0.225	0.534
1.5	-8.692	1.513	-1.046	-0.185	-2.000	0.170	4.00	0.161	0.000	0.490	0.406	0.253	1.000	400	-1.025	1.974	1.88	1.18	0.564	0.296	0.300	0.222	0.411
2.0	-9.701	1.600	-0.978	-0.236	-2.000	0.170	4.00	0.094	0.000	0.371	-0.456	0.300	1.000	400	-0.299	2.019	1.88	1.18	0.571	0.296	0.300	0.226	0.331
3.0	-10.556	1.600	-0.638	-0.491	-2.000	0.170	4.00	0.000	0.000	0.154	-0.820	0.300	1.000	400	0.000	2.110	1.88	1.18	0.558	0.326	0.300	0.229	0.289
4.0	-11.212	1.600	-0.316	-0.770	-2.000	0.170	4.00	0.000	0.000	0.000	-0.820	0.300	1.000	400	0.000	2.200	1.88	1.18	0.576	0.297	0.300	0.237	0.261
5.0	-11.684	1.600	-0.070	-0.986	-2.000	0.170	4.00	0.000	0.000	0.000	-0.820	0.300	1.000	400	0.000	2.291	1.88	1.18	0.601	0.359	0.300	0.237	0.200
7.5	-12.505	1.600	-0.070	-0.656	-2.000	0.170	4.00	0.000	0.000	0.000	-0.820	0.300	1.000	400	0.000	2.517	1.88	1.18	0.628	0.428	0.300	0.271	0.174
10.0	-13.087	1.600	-0.070	-0.422	-2.000	0.170	4.00	0.000	0.000	0.000	-0.820	0.300	1.000	400	0.000	2.744	1.88	1.18	0.667	0.485	0.300	0.290	0.174
0	-1.715	0.500	-0.530	-0.262	-2.118	0.170	5.60	0.280	-0.120	0.490	1.058	0.040	0.610	865	-1.186	1.839	1.88	1.18	0.478	0.219	0.300	0.166	1.000
-1	0.954	0.696	-0.309	-0.019	-2.016	0.170	4.00	0.245	0.000	0.358	1.694	0.092	1.000	400	-1.955	1.929	1.88	1.18	0.484	0.203	0.300	0.190	0.691
-2	-5.270	1.600	-0.070	0.000	-2.000	0.170	4.00	0.000	0.000	0.000	-0.820	0.300	1.000	400	0.000	2.744	1.88	1.18	0.667	0.485	0.300	0.290	0.174
-3	-4.354	0.942	-0.178	-0.346	-1.309	0.087	7.24	0.111	-0.108	0.362	2.549	0.090	1.277	400	-2.690	1.00	1.88	1.18	0.371	0.196	0.300	0.089	0.735];

T_CB2008 = coefficients(:,1);

%% Specify coefficients for period of interest or PGA, PGV, and PGD
rowIndex = find(T_CB2008==T);
c0 = coefficients(rowIndex,2);
c1 = coefficients(rowIndex,3);
c2 = coefficients(rowIndex,4);
c3 = coefficients(rowIndex,5);
c4 = coefficients(rowIndex,6);
c5 = coefficients(rowIndex,7);
c6 = coefficients(rowIndex,8);
c7 = coefficients(rowIndex,9);
c8 = coefficients(rowIndex,10);
c9 = coefficients(rowIndex,11);
c10 = coefficients(rowIndex,12);
c11 = coefficients(rowIndex,13);
c12 = coefficients(rowIndex,14);
k1 = coefficients(rowIndex,15);
k2 = coefficients(rowIndex,16);
k3 = coefficients(rowIndex,17);
c = coefficients(rowIndex,18);
n = coefficients(rowIndex,19);
slnY = coefficients(rowIndex,20);
tlnY = coefficients(rowIndex,21);
slnAF = coefficients(rowIndex,22);
sC = coefficients(rowIndex,23);
rho = coefficients(rowIndex,24);

%% Magnitude term
if (M<=5.5); 
    fmag = c0 + c1*M;
elseif (M>5.5 && M<=6.5);
    fmag = c0 + c1*M + c2*(M-5.5);
else
    fmag = c0 + c1*M + c2*(M-5.5) + c3*(M-6.5);
end

%% Distance term
fdis = (c4 + c5*M)*log(sqrt(Rrup^2+c6^2));

%% Mechanism term
if (ZTOR<1);
    ffltZ = ZTOR;
else
    ffltZ = 1;
end
fflt = c7*FRV*ffltZ + c8*FNM;

%% Hanging-wall term
if (Rjb==0);
    fhngR = 1;
elseif (Rjb>0 && ZTOR<1);
    fhngR = (max(Rrup,sqrt(Rjb^2+1))-Rjb)/max(Rrup,sqrt(Rjb^2+1));
elseif (Rjb>0 && ZTOR>=1);
    fhngR = (Rrup-Rjb)/Rrup;
else
    fprintf('Rjb is negative\n');
end

if (M<=6.0);
    fhngM = 0;
elseif (M>6.0 && M<6.5);
    fhngM = 2*(M-6);
else
    fhngM = 1;
end

if (ZTOR>=20);
    fhngZ = 0;
elseif (ZTOR>=0 && ZTOR <20);
    fhngZ = (20-ZTOR)/20;
else
    fprintf('ZTOR is negative\n');
end

if (dip<=70);
    fhngDip = 1;
else
    fhngDip = (90-dip)/20;
end

fhng = c9*fhngR*fhngM*fhngZ*fhngDip;

%% Shallow site response term
if (VS30<k1);
    A1100 = CB2008_A1100(M,Rrup,Rjb,FRV,FNM,ZTOR,dip,Z2pt5);
    fsite = c10*log(VS30/k1) + k2*(log(A1100+c*(VS30/k1)^n)-log(A1100+c));
elseif (VS30>=k1 && VS30<1100);
    fsite = (c10+k2*n)*log(VS30/k1);
else
    fsite = (c10+k2*n)*log(1100/k1);
end

%% Basin response term
if (Z2pt5<1);
    fsed = c11*(Z2pt5-1);
elseif (Z2pt5>=1 && Z2pt5<=3);
    fsed = 0;
else
    fsed = c12*k3*exp(-0.75)*(1-exp(-0.25*(Z2pt5-3)));
end

%% GM prediction
lnYhat = fmag + fdis + fflt + fhng + fsite + fsed;
Ageomean = exp(lnYhat);

%% Compute sigma for arbitrary horizontal component
% Inter-event standard deviation
t = tlnY;

% Standard deviation of ground motion at the base of the site profile
slnYB = sqrt(slnY^2-slnAF^2);

% Linearized functional relationship between fsite and ln(A1100)
if (VS30<k1);
    alpha = k2*A1100*((A1100+c*(VS30/k1)^n)^-1 - (A1100+c)^-1);
else
    alpha = 0;
end

% Standard deviation of PGA at the base of the site profile
slnPGA = coefficients(coefficients(:,1)==0,20);

% Standard deviation of PGA on reference rock at the base of the site profile
slnAB = sqrt(slnPGA^2-slnAF^2);

% Intra-event standard deviation
s = sqrt(slnYB^2 + slnAF^2 + alpha^2*slnAB^2 + 2*alpha*rho*slnYB*slnAB);

% Total standard deviation
sT = sqrt(s^2+t^2);

% Aleatory uncertainty of the arbitrary horizontal component
sArb = sqrt(sT^2+sC^2);

end