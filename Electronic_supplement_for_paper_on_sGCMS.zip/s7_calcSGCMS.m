%% Determine s-GCMS using previously computed data for T* and mean scenario
%{
NOTE:
Inputs:  
    - OpenSHA data
    - Previously computed UHS data
    - Previously computed disaggregation data
    - Choice of vibration periods for computing spectrum
    - Assumptions about mean scenario
       
Outputs:
    - Median spectrum associated with mean scenario
    - s-GCMS        
    - Corresponding outputs associated with sigma_Arb

Author: Neal Simon Kwong
%}
clear variables; close all; clc;

%% Inputs 
% Load data from OpenSHA
load('.\OpenSHAdata.mat');

% Load UHS
load('.\PSHAout_UHS.mat');

% Load disaggregation data
load('.\PSHAout_Disagg_vector.mat');

% Specify vibration periods for computing s-GCMS
T_sgcms = union( T_uhs, Tstar ); % change var name

% Specify output dir and filename
outputDir = '.\';
outputFilename = 'PSHAout_sGCMS.mat';

%% Compute median spectrum corresponding to mean scenario from disaggregation
% Assume mean scenario is vertically dipping, SS fault that ruptures at
% surface. Can revise this if desired.
FRV=0; FNM=0; ZTOR=0; dip=90; 

% From site info
VS30=400;
Z2pt5=1; % For removing discrepancy btw OpenSHA GUI and OpenSHA cmd-line apps

% From disaggregation
Mbar = meanScenario(1);
Rbar = meanScenario(2);

% Apply GMPM
Ageomean = zeros(size(T_sgcms));
sT = zeros(size(T_sgcms));
for ii=1:length(T_sgcms)
    [Ageomean(ii), sT(ii)] = CB2008(Mbar,Rbar,Rbar,FRV,FNM,ZTOR,dip,VS30,Z2pt5,T_sgcms(ii));
end

%% Determine epsilon at T*
MU_Tstar = log(Ageomean(ismember(T_sgcms,Tstar)));
SIGMA_Tstar = sT(ismember(T_sgcms,Tstar));
epsilon_Tstar = (log(tgtSA) - MU_Tstar) ./ SIGMA_Tstar;

%% Compute correlations between (epsilons at) all vibration periods
% Get correlations for all possible combinations
corrMatrix_all = zeros(length(T_sgcms));
for ii=1:length(T_sgcms)
    for jj=1:length(T_sgcms)
        corrMatrix_all(ii,jj) = baker_jayaram_correlation(T_sgcms(ii),T_sgcms(jj));        
    end
end

% Extract correlations
rho12 = corrMatrix_all( T_sgcms==Tstar(1), T_sgcms==Tstar(2) ); % Get correlation btw both T*
rhoj1 = corrMatrix_all( :, T_sgcms==Tstar(1) );
rhoj2 = corrMatrix_all( :, T_sgcms==Tstar(2) );

% Get coefficients for combining epsilons at both T*
cj1 = (rhoj1 - rho12*rhoj2) / (1-rho12^2);
cj2 = (rhoj2 - rho12*rhoj1) / (1-rho12^2);

%% Determine epsilon at other vibration periods
generalizedEpsilon = ( [cj1 cj2] * epsilon_Tstar' )';

%% Determine target spectrum
sGCMS = Ageomean .* exp(generalizedEpsilon.*sT);

%% Save data
save(fullfile(outputDir,outputFilename),...
    'T_sgcms',...
    'Ageomean','sT','sGCMS');



%% Repeat calcs for sigma_Arb
% Compute median spectrum corresponding to mean scenario from disaggregation
FRV=0; FNM=0; ZTOR=0; dip=90; 
VS30=400;
Z2pt5=1; % For removing discrepancy btw OpenSHA GUI and OpenSHA cmd-line apps
Mbar = meanScenario(1);
Rbar = meanScenario(2);

% Apply GMPM
Ageomean = zeros(size(T_sgcms));
sArb = zeros(size(T_sgcms));
for ii=1:length(T_sgcms)
    [Ageomean(ii), ~, sArb(ii)] = CB2008(Mbar,Rbar,Rbar,FRV,FNM,ZTOR,dip,VS30,Z2pt5,T_sgcms(ii));
end

% Determine epsilon at T*
MU_Tstar = log(Ageomean(ismember(T_sgcms,Tstar)));
SIGMA_Tstar = sArb(ismember(T_sgcms,Tstar));
epsilon_Tstar_Arb = (log(tgtSA_Arb) - MU_Tstar) ./ SIGMA_Tstar;

% Determine epsilon at other vibration periods
generalizedEpsilon = ( [cj1 cj2] * epsilon_Tstar_Arb' )';

% Determine target spectrum
sGCMS_Arb = Ageomean .* exp(generalizedEpsilon.*sArb);

%% Append data
save(fullfile(outputDir,outputFilename),...    
    'sArb','sGCMS_Arb','epsilon_Tstar_Arb','-append');



%% Plot s-GCMS
ymin = 1e-2; ymax = 2;

% Create figure;
figure;
loglog(T_uhs,UHS,'k-');
hold on;
plot(T_sgcms,Ageomean,'k--');
plot(T_sgcms,sGCMS,'r-.')
plot(Tstar,tgtSA,'go');

% Format axes
xlim([T_uhs(1) T_uhs(end)]);
ylim([ymin ymax]);

% Format labels
legend('UHS','Median','s-GCMS','Target SA values','location','SW');
xlabel('Period [sec]');
ylabel('Spectral acceleration [g]');
