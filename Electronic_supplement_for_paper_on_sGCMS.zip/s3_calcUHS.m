%% Determine UHS for the site
%{
Inputs:  
    - Hazard level for UHS
        -- Exposure time
        -- Target probability
    - Vibration periods for computing UHS T_uhs
    - IMHC data
        
Outputs:
    - UHS based on sigma_Geo
    - UHS based on sigma_Arb

Author: Neal Simon Kwong
%}
clear variables; close all; clc;

%% Inputs
% Load IMHCs
load('.\PSHAout_IMHC.mat');

% Specify hazard level
exposureTime = 50;
tgtProb = 2; % In units of percent

% Vibration periods for computing UHS
T_uhs = union(logspace(-2,1,150), T');

% Specify output dir and filename
outputDir = '.\';
outputFilename = 'PSHAout_UHS.mat';

%% Determine target hazard level
% Poisson assumption
tgtRate = -log(1-tgtProb/100)/ exposureTime;

%% Compute UHS (based on sigma_geo)
% Get UHS based on vib per used as inputs for GMPM
UHS_temp = zeros(1,length(T));
for ii=1:length(T)
    [~,idUnique] = unique(IMHC(:,ii)); % Determine unique pts on IMHC
    UHS_temp(1,ii) = exp(  interp1( log(IMHC(idUnique,ii)), log(IMtestPts(idUnique)), log(tgtRate) )  ); % Interpolate on log scale 
end

% Interpolate on log scale
UHS = exp(  interp1(log(T),log(UHS_temp), log(T_uhs))  );

%% Save data
save(fullfile(outputDir,outputFilename),...
    'exposureTime','tgtProb','tgtRate',...
    'T_uhs','UHS');



%% Compute UHS (based on sigma_arb)
% Get UHS based on vib per used as inputs for GMPM
UHS_temp = zeros(1,length(T));
for ii=1:length(T)  
    [~,idUnique] = unique(IMHC_Arb(:,ii)); % Determine unique pts on IMHC
    UHS_temp(1,ii) = exp(  interp1( log(IMHC_Arb(idUnique,ii)), log(IMtestPts(idUnique)), log(tgtRate) )  ); % Interpolate on log scale     
end

% Interpolate on log scale
UHS_Arb = exp(  interp1(log(T),log(UHS_temp), log(T_uhs))  );

%% Append data
save(fullfile(outputDir,outputFilename),...    
    'UHS_Arb','-append');



%% Plot UHS
% Create figure
figure;
loglog(T_uhs,UHS);
hold on;
plot(T_uhs,UHS_Arb,'r--');

% Format axes
grid on;
xlim([T_uhs(1) T_uhs(end)]);

% Format labels
xlabel(['Period [sec]']);
ylabel('Spectral acceleration [g]');
title(['UHS for ' int2str(tgtProb) '% in ' int2str(exposureTime) ' yrs'])
legend('Geomean','Arbitrary');
