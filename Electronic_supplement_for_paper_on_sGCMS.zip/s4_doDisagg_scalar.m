%% Perform scalar-valued disaggregation
%{
NOTE:
    This file is for hazard defined by SA(T)=tgtSA; not SA(T)>tgtSA

Inputs:  
    - OpenSHA data
    - Previously computed UHS data
    - Choice of vibration period for disaggregation
       
Outputs:
    - Target SA value corresponding to specified hazard level
    - Percent contribution of each rupture to specified hazard
    - Mean earthquake scenario
    - Corresponding outputs associated with sigma_Arb

Author: Neal Simon Kwong
%}
clear variables; close all; clc;

%% Inputs
% Load data from OpenSHA
load('.\OpenSHAdata.mat');

% Load UHS
load('.\PSHAout_UHS.mat');

% Specify vibration period of interest
Tstar = 1; % Conditioning period

% Specify output dir and filename
outputDir = '.\';
outputFilename = 'PSHAout_Disagg_scalar.mat';

%% Get target SA values corresponding to specified hazard level
% Interpolate on log scale
tgtSA = exp(  interp1(log(T_uhs),log(UHS),log(Tstar))  );

%% Prepare for disaggregation
% Determine GMPM output for chosen period and for each rupture scenario
MUs_Tstar = interp1(log(T),MUs',log(Tstar))';
SIGMAs_Tstar = interp1(log(T),SIGMAs',log(Tstar))';

% Compute epsilon for each rupture scenario
EPSILONs = ( log(tgtSA) - MUs_Tstar ) ./ SIGMAs_Tstar;

%% Perform disaggregation 
% Calc percent contribution for each rupture scenario
PDFgivenRup = normpdf( log(tgtSA), MUs_Tstar, SIGMAs_Tstar ); % Pr(SA=tgtSA|rup) = Pr(lnSA=lntgtSA|rup) = f(x)dx
percContr = (PDFgivenRup .* rupRates) / (PDFgivenRup' * rupRates); % Differentials dx cancel

% Determine mean scenario
Mbar = percContr' * M;
RRUPbar = percContr' * Rrup;
RJBbar = percContr' * Rjb;
Ebar = percContr' * EPSILONs;
meanScenario = [Mbar RRUPbar RJBbar Ebar];

%% Save data
save(fullfile(outputDir,outputFilename),...
    'Tstar',...
    'tgtSA','EPSILONs',...
    'percContr','meanScenario');



%% Repeat disaggregation based on sigma_Arb
% Interpolate on log scale
tgtSA_Arb = exp(  interp1(log(T_uhs),log(UHS_Arb),log(Tstar))  );

% Determine GMPM output for chosen period and for each rupture scenario
MUs_Tstar = interp1(log(T),MUs',log(Tstar))';
SIGMAs_Tstar = interp1(log(T),SIGMAs_Arb',log(Tstar))';

% Compute epsilon for each rupture scenario
EPSILONs_Arb = ( log(tgtSA_Arb) - MUs_Tstar ) ./ SIGMAs_Tstar;

% Calc percent contribution for each rupture scenario
PDFgivenRup = normpdf( log(tgtSA_Arb), MUs_Tstar, SIGMAs_Tstar ); % Pr(SA=tgtSA|rup) = Pr(lnSA=lntgtSA|rup) = f(x)dx
percContr_Arb = (PDFgivenRup .* rupRates) / (PDFgivenRup' * rupRates); % Differentials dx cancel

% Determine mean scenario
Mbar = percContr_Arb' * M;
RRUPbar = percContr_Arb' * Rrup;
RJBbar = percContr_Arb' * Rjb;
Ebar = percContr_Arb' * EPSILONs_Arb;
meanScenario_Arb = [Mbar RRUPbar RJBbar Ebar];

%% Append data
save(fullfile(outputDir,outputFilename),...    
    'tgtSA_Arb','EPSILONs_Arb',...
    'percContr_Arb','meanScenario_Arb','-append');
