%% Read output from OpenSHA command-line application
%{
Inputs:
    - Directory containing output from OpenSHA app
    - GMPM specified for PSHA
    - List of vibration periods T considered for PSHA

Outputs:
    - Total number of rupture scenarios considered in PSHA
    - For each rupture scenario,
        -- Annual rate of occurrence
        -- Mean and std dev associated with SA(T), for each T
        -- Magnitude
        -- Closest distance
        -- Joyner-Boore distance

Author: Neal Simon Kwong
%}
clear variables; close all; clc;

%% Inputs
% Directory containing output from OpenSHA IMeventSetCalc cmd line app
OpenSHAoutDir = '.\OpenSHA\Output'; 

% Specify string corresponding to GMPM chosen for OpenSHA input file
GMPEstr = 'CB2008';

% Specify vibration periods used for OpenSHA input file
T = [0.01, 0.02, 0.03, 0.05, 0.075, 0.1, 0.15, 0.2, 0.25, 0.3, 0.4, 0.5, 0.75, 1, 1.5, 2, 3, 4, 5, 7.5, 10]'; % Periods for CB2008 GMPM

% Total number of vibration periods considered
nPer = length(T);

% Specify output dir and filename
outputDir = '.\';
outputFilename = 'OpenSHAdata.mat';

%% Get metadata for all rupture scenarios
% Read data from txt file
fileID = fopen(fullfile(OpenSHAoutDir,'src_rup_metadata.txt'));
data = textscan(fileID, '%d %d %f %f %*[^\n]');
fclose(fileID);

% Total number of rupture scenarios
numScenarios = length( data{1} );

% Annual rate of occurrence
rupRates = data{3};

% Magnitude
M = data{4};

% Closest distance Rrup
temp = load(fullfile(OpenSHAoutDir,'rup_dist_info.txt'));
Rrup = temp(:,3);

% Joyner-Boore distance Rjb
temp = load(fullfile(OpenSHAoutDir,'rup_dist_jb_info.txt'));
Rjb = temp(:,3);

%% Get GMPM output for all rupture scenarios
% Initialize vars to save GMPM output for all scenarios and all T
MUs = zeros(numScenarios,nPer);
SIGMAs = zeros(numScenarios,nPer);
for ii=1:nPer    
    % Make string for vibration period
    Tstr = sprintf('%03.3f',T(ii));
    
    % Construct filename
    GMPMoutFilename = [GMPEstr '_SA_' Tstr '.txt'];
    
    % Get GMPM output
    GMPMoutput = load(fullfile(OpenSHAoutDir,GMPMoutFilename));
    
    % Store mean and std dev
    MUs(:,ii) = GMPMoutput(:,3);
    SIGMAs(:,ii) = GMPMoutput(:,4);   
end
    
%% Save data
save(fullfile(outputDir,outputFilename),...
    'GMPEstr','T','nPer',...
    'numScenarios','rupRates','M','Rrup','Rjb',...
    'MUs','SIGMAs');



%% Determine std dev corresponding to arbitrary horizontal component of GM
%{
Inflate sT using sC from CB2008 GMPM.
Determine sC for all vibration periods. 
sC depends only on T so other seismological param are not impt.
%}
sC = zeros(1,nPer);
for ii=1:nPer
    [~,sT,sArb] = CB2008(7,10,10,0,0,0,90,600,3,T(ii));
    sC(1,ii) = sqrt(sArb^2-sT^2);
end

% Inflate std dev to reflect arb horiz comp
SIGMAs_Arb = sqrt(  SIGMAs.^2 + repmat(sC,numScenarios,1).^2  );

%% Append data
save(fullfile(outputDir,outputFilename),...
    'SIGMAs_Arb','-append');
