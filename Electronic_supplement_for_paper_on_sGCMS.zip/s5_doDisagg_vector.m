%% Perform vector-valued disaggregation for the site
%{
NOTE:
    This file is for hazard defined by {SA1(T1)=tgtSA1, SA2(T2)=tgtSA2}

Inputs:  
    - OpenSHA data
    - Previously computed UHS data
    - Choice of vibration periods for disaggregation
       
Outputs:
    - Target SA values corresponding to specified hazard level
    - Percent contribution of each rupture to specified hazard
    - Mean earthquake scenario
    - Corresponding outputs associated with sigma_Arb

Author: Neal Simon Kwong
%}
clear variables; close all; clc;

%% Inputs
% Load data from OpenSHA
load('.\OpenSHAdata.mat');

% Load UHS
load('.\PSHAout_UHS.mat');

% Specify vibration period of interest
Tstar = [0.3 1.5]; % Conditioning periods
numTstar = length(Tstar);

% Specify output dir and filename
outputDir = '.\';
outputFilename = 'PSHAout_Disagg_vector.mat';

%% Get target SA values corresponding to specified hazard level
% Interpolate on log scale
tgtSA = exp(  interp1(log(T_uhs),log(UHS),log(Tstar))  );

%% Prepare for disaggregation
% Determine GMPM output for chosen period and for each rupture scenario
MUs_Tstar = interp1(log(T),MUs',log(Tstar))';
SIGMAs_Tstar = interp1(log(T),SIGMAs',log(Tstar))';

% Compute epsilon for each rupture scenario
EPSILONs = bsxfun( @minus, log(tgtSA), MUs_Tstar ) ./ SIGMAs_Tstar;

% Determine correlation matrix for multivariate PDF of SA at chosen periods
% given rupture scenario. Assume correlations are independent of rupture
% scenarios.
corrMatrix_Tstar = zeros(numTstar); % Make sure Tstar is a member of T
for ii=1:numTstar
    for jj=1:numTstar
        corrMatrix_Tstar(ii,jj) = baker_jayaram_correlation(Tstar(ii),Tstar(jj)); % Use Baker Jayaram 2008 model
    end
end

% Determine covariance matrix for multivariate PDF for SA at chosen periods
% given rupture scenario
COVs_Tstar = zeros(numTstar,numTstar,numScenarios);
for ii=1:numScenarios
    COVs_Tstar(:,:,ii) = diag(SIGMAs_Tstar(ii,:)) * corrMatrix_Tstar * diag(SIGMAs_Tstar(ii,:));
end

%% Perform disaggregation 
% Calc percent contribution for each rupture scenario
PDFgivenRup = mvnpdf( log(tgtSA), MUs_Tstar, COVs_Tstar ); % Pr(SA=tgtSA|rup) = Pr(lnSA=lntgtSA|rup) = f(x1,x2)dx1dx2
percContr = (PDFgivenRup .* rupRates) / (PDFgivenRup' * rupRates); % Differentials dx1 dx2 cancel
                
% Determine mean scenario
Mbar = percContr' * M;
RRUPbar = percContr' * Rrup;
RJBbar = percContr' * Rjb;
Ebar = percContr' * EPSILONs;
meanScenario = [Mbar RRUPbar RJBbar Ebar];

%% Save data
save(fullfile(outputDir,outputFilename),...
    'Tstar',...
    'tgtSA','EPSILONs',...
    'percContr','meanScenario');



%% Repeat disaggregation based on sigma_Arb
% Interpolate on log scale
tgtSA_Arb = exp(  interp1(log(T_uhs),log(UHS_Arb),log(Tstar))  );

% Determine GMPM output for chosen period and for each rupture scenario
MUs_Tstar = interp1(log(T),MUs',log(Tstar))';
SIGMAs_Tstar = interp1(log(T),SIGMAs_Arb',log(Tstar))';

% Compute epsilon for each rupture scenario
EPSILONs_Arb = bsxfun( @minus, log(tgtSA_Arb) , MUs_Tstar ) ./ SIGMAs_Tstar;

% Determine covariance matrix for multivariate PDF for SA at chosen periods
% given rupture scenario
COVs_Tstar = zeros(numTstar,numTstar,numScenarios);
for ii=1:numScenarios
    COVs_Tstar(:,:,ii) = diag(SIGMAs_Tstar(ii,:)) * corrMatrix_Tstar * diag(SIGMAs_Tstar(ii,:));
end

% Calc percent contribution for each rupture scenario
PDFgivenRup = mvnpdf( log(tgtSA_Arb), MUs_Tstar, COVs_Tstar ); % Pr(SA=tgtSA|rup) = Pr(lnSA=lntgtSA|rup) = f(x1,x2)dx1dx2
percContr_Arb = (PDFgivenRup .* rupRates) / (PDFgivenRup' * rupRates);

% Determine mean scenario
Mbar = percContr_Arb' * M;
RRUPbar = percContr_Arb' * Rrup;
RJBbar = percContr_Arb' * Rjb;
Ebar = percContr_Arb' * EPSILONs_Arb;
meanScenario_Arb = [Mbar RRUPbar RJBbar Ebar];

%% Append data
save(fullfile(outputDir,outputFilename),...    
    'tgtSA_Arb','EPSILONs_Arb',...
    'percContr_Arb','meanScenario_Arb','-append');
