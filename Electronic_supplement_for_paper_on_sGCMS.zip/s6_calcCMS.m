%% Determine CMS using previously computed data for T* and mean scenario
%{
NOTE:
Inputs:  
    - OpenSHA data
    - Previously computed UHS data
    - Previously computed disaggregation data
    - Choice of vibration periods for computing spectrum
    - Assumptions about mean scenario
       
Outputs:
    - Median spectrum associated with mean scenario
    - CMS        
    - Corresponding outputs associated with sigma_Arb

Author: Neal Simon Kwong
%}
clear variables; close all; clc;

%% Inputs 
% Load data from OpenSHA
load('.\OpenSHAdata.mat');

% Load UHS
load('.\PSHAout_UHS.mat');

% Load disaggregation data
load('.\PSHAout_Disagg_scalar.mat');

% Specify vibration periods for computing CMS
T_cms = union( T_uhs, Tstar );

% Specify output dir and filename
outputDir = '.\';
outputFilename = 'PSHAout_CMS.mat';

%% Compute median spectrum corresponding to mean scenario from disaggregation
% Assume mean scenario is vertically dipping, SS fault that ruptures at
% surface. Can revise this if desired.
FRV=0; FNM=0; ZTOR=0; dip=90; 

% From site info
VS30=400;
Z2pt5=1; % For removing discrepancy btw OpenSHA GUI and OpenSHA cmd-line apps

% From disaggregation
Mbar = meanScenario(1);
Rbar = meanScenario(2);

% Apply GMPM
Ageomean = zeros(size(T_cms));
sT = zeros(size(T_cms));
for ii=1:length(T_cms)
    [Ageomean(ii), sT(ii)] = CB2008(Mbar,Rbar,Rbar,FRV,FNM,ZTOR,dip,VS30,Z2pt5,T_cms(ii));
end

%% Determine epsilon at T*
MU_Tstar = log(Ageomean(ismember(T_cms,Tstar)));
SIGMA_Tstar = sT(ismember(T_cms,Tstar));
epsilon_Tstar = (log(tgtSA)-MU_Tstar) / SIGMA_Tstar;

%% Compute correlations between (epsilons at) all vibration periods
corrVector = zeros(size(T_cms));
for ii=1:length(T_cms)
    corrVector(ii) = baker_jayaram_correlation(T_cms(ii),Tstar);
end

%% Determine epsilon at other vibration periods
generalizedEpsilon = epsilon_Tstar * corrVector;

%% Determine target spectrum
CMS = Ageomean .* exp(generalizedEpsilon.*sT);

%% Save data
save(fullfile(outputDir,outputFilename),...
    'T_cms',...
    'Ageomean','sT','CMS');



%% Repeat calcs for sigma_Arb
% Compute median spectrum corresponding to mean scenario from disaggregation
FRV=0; FNM=0; ZTOR=0; dip=90; 
VS30=400;
Z2pt5=1; % For removing discrepancy btw OpenSHA GUI and OpenSHA cmd-line apps
Mbar = meanScenario(1);
Rbar = meanScenario(2);

% Apply GMPM
Ageomean = zeros(size(T_cms)); % Median spectrum unaffected by sigma_Arb
sArb = zeros(size(T_cms));
for ii=1:length(T_cms)
    [Ageomean(ii), ~, sArb(ii)] = CB2008(Mbar,Rbar,Rbar,FRV,FNM,ZTOR,dip,VS30,Z2pt5,T_cms(ii));
end

% Determine epsilon at T*
MU_Tstar = log(Ageomean(ismember(T_cms,Tstar)));
SIGMA_Tstar = sArb(ismember(T_cms,Tstar));
epsilon_Tstar = (log(tgtSA_Arb)-MU_Tstar) / SIGMA_Tstar;

% Determine epsilon at other vibration periods
generalizedEpsilon = epsilon_Tstar * corrVector;

% Determine target spectrum
CMS_Arb = Ageomean .* exp(generalizedEpsilon.*sArb);

%% Append data
save(fullfile(outputDir,outputFilename),...    
    'sArb','CMS_Arb','-append');



%% Plot CMS
ymin = 1e-2; ymax = 2;

% Create figure;
figure;
loglog(T_uhs,UHS,'k-');
hold on;
plot(T_cms,Ageomean,'k--');
plot(T_cms,CMS,'r--');
plot(Tstar,tgtSA,'go');

% Format axes
xlim([T_uhs(1) T_uhs(end)]);
ylim([ymin ymax]);

% Format labels
legend('UHS','Median','CMS','Target SA value','location','SW');
xlabel('Period [sec]');
ylabel('Spectral acceleration [g]');
