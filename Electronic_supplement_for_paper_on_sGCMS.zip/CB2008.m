%% Function for implementing Campbell and Bozorgnia 2008 GMPE
% By Neal (Simon) Kwong (nealsimonkwong@berkeley.edu)
% Last modified: 2/7/2014
function [Ageomean, sT, sArb]= CB2008(M,Rrup,Rjb,FRV,FNM,ZTOR,dip,VS30,Z2pt5,T)
%{
- 1/21/14: Added T=-3 option to trigger coefficients for CAV from CB2010
- 2/07/14: Updated comments to indicate units for IMs that are not A(T)
%}
%% ------------------------INPUT VARIABLES --------------------------------
% M     = Moment magnitude
% Rrup  = Closest Euclidean distance between site and rupture plane (km)
% Rjb   = Closest distance to the surface projection of rupture plane (km)
% FRV   = Indicator variable for reverse or reverse-oblique faulting
% FNM   = Indicator variable for normal or normal-oblique faulting
% ZTOR  = Depth to the top of the rupture plane (km)
% dip   = Dip of the rupture plane (degrees)
% VS30  = Time-averaged shear-wave velocity in the top 30m of site profile (m/s)
% Z2pt5 = Basin or sediment depth (km)
% T     = Period of linear SDOF oscillator or ground motion (sec). If PGA,
%         PGV, or PGD is desired, enter 0, -1, or -2 respectively. If
%         T>=0.01 and T<=10, then linear interpolation is used. If T is 
%         none of the above, then function returns an error message.

%% Periods available for using CB08
T_CB2008 = [0.01,0.02,0.03,0.05,0.075,0.1,0.15,0.2,0.25,0.3,0.4,0.5,0.75,1.0,1.5,2.0,3.0,4.0,5.0,7.5,10.0]; 

%% Execute GMPE for desired T
if ismember(T,[0 -1 -2 -3])
    % Return output for PGA (g), PGV (cm/s), PGD (cm), or CAV (g-sec)
    [Ageomean, sT, sArb] = CB2008_fixedT(M,Rrup,Rjb,FRV,FNM,ZTOR,dip,VS30,Z2pt5,T);
elseif T>=min(T_CB2008) && T<=max(T_CB2008)
    % Determine neighboring periods
    T_lo = T_CB2008(find(T_CB2008<=T,1,'last'));
    T_up = T_CB2008(find(T_CB2008>=T,1,'first'));
    % Determine if linear interpolation is necessary
    if T_lo~=T_up
        % Determine output for neighboring periods
        [Ageomean_lo, sT_lo, sArb_lo] = CB2008_fixedT(M,Rrup,Rjb,FRV,FNM,ZTOR,dip,VS30,Z2pt5,T_lo);
        [Ageomean_up, sT_up, sArb_up] = CB2008_fixedT(M,Rrup,Rjb,FRV,FNM,ZTOR,dip,VS30,Z2pt5,T_up);
        % Linearly interpolate
        Ageomean = exp(interp1(log([T_lo T_up]),log([Ageomean_lo Ageomean_up]),log(T)));
        sT = interp1(log([T_lo T_up]),[sT_lo sT_up],log(T));
        sArb = interp1(log([T_lo T_up]),[sArb_lo sArb_up],log(T));
    else
        % Input T is an element of T_CB2008
        [Ageomean, sT, sArb] = CB2008_fixedT(M,Rrup,Rjb,FRV,FNM,ZTOR,dip,VS30,Z2pt5,T);
    end
else
    fprintf('Invalid period argument, T\n');
    disp(['Input period is ' num2str(T,4)]);
end

end